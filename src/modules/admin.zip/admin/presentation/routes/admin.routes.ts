// src/modules/admin/presentation/routes/admin.routes.ts
import { Router } from "express";
import { authenticateToken } from "../../../../middlewares/authenticate_token";
import { asyncHandler } from "../../../../middlewares/async_handler";
import { AdminController } from "../controllers/admin.controller";

const router = Router();
const ctrl = new AdminController();

/* ---------- CREATE ---------- */
router.post("/article_categories", authenticateToken, asyncHandler((req, res) => ctrl.registerArticleCategory(req, res)));
router.post("/service_categories", authenticateToken, asyncHandler((req, res) => ctrl.registerServiceCategory(req, res)));
router.post("/community_categories", authenticateToken, asyncHandler((req, res) => ctrl.registerCommunityCategory(req, res)));
router.post("/case_categories", authenticateToken, asyncHandler((req, res) => ctrl.registerCaseCategory(req, res)));
router.post("/case_statuses", authenticateToken, asyncHandler((req, res) => ctrl.registerCaseStatus(req, res)));
router.post("/attachment_categories", authenticateToken, asyncHandler((req, res) => ctrl.registerAttachmentCategory(req, res)));

/* ---------- UPDATE ---------- */
router.put("/article_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.updateArticleCategory(req, res)));
router.put("/service_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.updateServiceCategory(req, res)));
router.put("/community_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.updateCommunityCategory(req, res)));
router.put("/case_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.updateCaseCategory(req, res)));
router.put("/case_statuses/:id", authenticateToken, asyncHandler((req, res) => ctrl.updateCaseStatus(req, res)));
router.put("/attachment_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.updateAttachmentCategory(req, res)));

/* ---------- DELETE ---------- */
router.delete("/article_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.deleteArticleCategory(req, res)));
router.delete("/service_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.deleteServiceCategory(req, res)));
router.delete("/community_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.deleteCommunityCategory(req, res)));
router.delete("/case_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.deleteCaseCategory(req, res)));
router.delete("/case_statuses/:id", authenticateToken, asyncHandler((req, res) => ctrl.deleteCaseStatus(req, res)));
router.delete("/attachment_categories/:id", authenticateToken, asyncHandler((req, res) => ctrl.deleteAttachmentCategory(req, res)));

/* ---------- GET ---------- */
router.get("/article_categories", asyncHandler((req, res) => ctrl.getArticleCategories(req, res)));
router.get("/service_categories", asyncHandler((req, res) => ctrl.getServiceCategories(req, res)));
router.get("/community_categories", asyncHandler((req, res) => ctrl.getCommunityCategories(req, res)));
router.get("/case_categories", asyncHandler((req, res) => ctrl.getCaseCategories(req, res)));
router.get("/case_statuses", asyncHandler((req, res) => ctrl.getCaseStatuses(req, res)));
router.get("/attachment_categories", asyncHandler((req, res) => ctrl.getAttachmentCategories(req, res)));

export default router;
